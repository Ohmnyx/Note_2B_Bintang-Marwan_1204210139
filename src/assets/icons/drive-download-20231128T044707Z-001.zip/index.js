import IconHomeActive from './Home-Active.svg'
import IconProfileActive from './Profile-Active.svg'
import IconHome from './Home.svg'
import IconProfile from './Profile.svg'
import IconAddActive from './Add-Active.svg'
import IconAdd from './Add.svg'
import IconEdit from './edit.svg'
import IconDelete from './Delete.svg'
import IconLogo from './logo.svg'

export {
    IconHome,
    IconHomeActive,
    IconProfile,
    IconProfileActive,
    IconAdd,
    IconAddActive,
    IconEdit,
    IconDelete,
    IconLogo
};